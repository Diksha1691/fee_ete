# Todo List for the Project

1. [x] Add forms and Queries.
2. [x] CRUD Forms
3. [x] Refactor CSS.
4. [ ] Reusable Table Component
